def handler(event, context):
    print("EVENT\n" + str(event))
    return {'success': True}
